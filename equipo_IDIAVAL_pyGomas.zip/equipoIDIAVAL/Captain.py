import json
import math
from loguru import logger
from spade.behaviour import OneShotBehaviour
from spade.template import Template
from spade.message import Message
from pygomas.bditroop import BDITroop
from agentspeak import Actions
from agentspeak import grounded
from agentspeak.stdlib import actions as asp_action

from pygomas.agent import LONG_RECEIVE_WAIT

class CaptainBDI(BDITroop):

    def add_custom_actions(self, actions):
        super().add_custom_actions(actions)

        @actions.add_function(".calculatePos", (int, float))
        def _calculatePos(num_agents, arc_degrees):
            """
            Calcula el angulo entre agentes para una formacion en arco de `arc_degrees`.

            Args:
                num_agents (int): Numero total de agentes a posicionar.
                arc_degrees (float): Grados totales del arco en el que distribuirlos.

            Returns:
                float: Separacion angular entre cada par de agentes.
            """
            # Si hay mas de un agente, dividimos el arco entre los intervalos necesarios
            if num_agents > 1:
                return arc_degrees / (num_agents - 1)
            # Si solo hay un agente, no necesitamos desplazamiento angular
            else:
                return 0.0

        @actions.add_function(".squadForm", (tuple, tuple, float, float))
        def _squadForm(center, flag_pos, distance, angle_offset):
            """
            Calcula la posicion de un soldado en formacion en arco orientada hacia la bandera.

            Args:
                center (tuple): Coordenadas (x, y, z) del punto central de la formacion.
                flag_pos (tuple): Coordenadas (x, y, z) de la bandera.
                distance (float): Radio del arco desde center.
                angle_offset (float): Desplazamiento angular respecto al angulo base invertido.

            Returns:
                tuple: Coordenadas enteras (x, y, z) de la posicion calculada.
            """
            x0, y0, z0 = center
            xf, _, zf = flag_pos

            # Calculamos el angulo entre el centro y la bandera (radianes)
            dx = xf - x0
            dz = zf - z0
            base_angle_rad = math.atan2(dz, dx)
            
            # Convertimos el angulo base a grados
            base_angle_deg = math.degrees(base_angle_rad)

            # Invertimos el angulo base para revertir la orientacion del arco
            # y aplicamos el desplazamiento especifico de este agente
            angle_deg = -base_angle_deg + angle_offset
            rad = math.radians(angle_deg)

            # Calculamos coordenadas X,Z a partir del angulo y la distancia
            x = x0 + distance * math.cos(rad)
            z = z0 + distance * math.sin(rad)

            # Convertimos a enteros para la posicion final del agente
            return (int(x), y0, int(z))