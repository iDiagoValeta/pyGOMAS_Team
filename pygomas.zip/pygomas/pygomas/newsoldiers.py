import json
import random
import math
import sys
from loguru import logger
from spade.behaviour import OneShotBehaviour
from spade.template import Template
from spade.message import Message
from pygomas.agents.bditroop import BDITroop
from pygomas.agents.bdifieldop import BDIFieldOp
from pygomas.agents.bdimedic import BDIMedic
from agentspeak import Actions
from agentspeak.stdlib import actions as asp_action
from pygomas.ontology import Belief

from pygomas.agents.agent import LONG_RECEIVE_WAIT

class Capitan(BDIMedic):

      def add_custom_actions(self, actions):
            super().add_custom_actions(actions)
      
            @actions.add_function(".fuegoAmigo", (tuple, tuple, tuple))
            def _fuegoAmigo(mi_pos, enemi_pos, alli_pos):
                  '''
                        Comprueba si hay un amigo en el angulo de tiro. Más formalmente, comprueba si la posición
                        del aliado se encuentra en la recta que una la posición del tirador con la del objetivo.
                  '''
                  # Descomponer las posiciones en coordenadas
                  x1, y1 = mi_pos
                  x2, y2 = enemi_pos
                  x3, y3 = alli_pos

                  # Calcular el producto cruzado
                  crossproduct = (y3 - y1) * (x2 - x1) - (x3 - x1) * (y2 - y1)
                  if abs(crossproduct) > sys.float_info.epsilon:
                        return False
            
                  # Calcular el producto punto
                  dotproduct = (x3 - x1) * (x2 - x1) + (y3 - y1) * (y2 - y1)
                  if dotproduct < 0:
                        return False

                  # Calcular la longitud al cuadrado de la línea entre la posición propia y el enemigo
                  squaredlengthba = (x2 - x1) ** 2 + (y2 - y1) ** 2
                  if dotproduct > squaredlengthba:
                        return False

                  return True
            @actions.add_function(".puntoperativo", (tuple, tuple,))
            def _puntoperativo(mi_pos, flag_pos):
                  '''
                  Busco el punto de operaciones mas cercano
                  será un punto que este a 100 u.d. de la bandera
                  '''
                  puntos = []
                  cx, cy, cz = flag_pos
                  r = 110; n = 20;
                  for i in range(n):
                        # Calcular el ángulo para cada punto
                        theta = 2 * math.pi * i / n
                        # Calcular las coordenadas de cada punto
                        x = cx + r * math.cos(theta)
                        y = 0
                        z = cz + r * math.sin(theta)
                        puntos.append((x, y, z))
                  
                  punto_cercano = puntos[0]
                  menor_distancia = distancia_euclidiana(puntos[0], mi_pos)
                  
                  for punto in puntos[1:]:
                        distancia = distancia_euclidiana(punto, mi_pos)
                        if distancia < menor_distancia:
                              menor_distancia = distancia
                              punto_cercano = punto
                              
                  return punto_cercano

            def distancia_euclidiana(p1,p2):
                  """
                  Calcula la distancia euclidiana entre dos puntos p1 y p2.
                  
                  :param p1: Tuple (x, y) representando el primer punto.
                  :param p2: Tuple (x, y) representando el segundo punto.
                  :return: Distancia euclidiana entre p1 y p2.
                  """
                  return math.sqrt((p1[0] - p2[0])**2 + (p1[2] - p2[2])**2)
            