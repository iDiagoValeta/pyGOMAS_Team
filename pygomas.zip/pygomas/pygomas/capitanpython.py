import json
import random
import numpy as np
import matplotlib.pyplot as plt
from loguru import logger
from spade.behaviour import OneShotBehaviour
from spade.template import Template
from spade.message import Message
from .bditroop import BDITroop
from .bdifieldop import BDIFieldOp
from agentspeak import Actions
from agentspeak import grounded
from agentspeak.stdlib import actions as asp_action
from .ontology import Belief

from .agent import LONG_RECEIVE_WAIT

# Función para convertir coordenadas polares a cartesianas
def polar_to_cartesian(radius, angle):
    """
    Convierte coordenadas polares a cartesianas.

    Args:
        radius (float): El radio en coordenadas polares.
        angle (float): El ángulo en coordenadas polares.

    Returns:
        tuple: Coordenadas cartesianas (x, y).
    """
    x = radius * np.cos(angle)
    y = radius * np.sin(angle)
    return x, y

class BDICapitan(BDIFieldOp):
    """
    Clase que representa a un capitán BDI que extiende las funcionalidades de un BDIFieldOp.
    """
    def add_custom_actions(self, actions):
        """
        Agrega acciones personalizadas a las acciones del agente.
        
        Args:
            actions (Actions): El conjunto de acciones del agente.
        """
        super().add_custom_actions(actions)
        
        @actions.add(".calcularPosMedicos", 0)
        def _calcularPosMedicos(agent, term, intention):
            """
            Calcula las posiciones de los médicos alrededor de un origen en una formación circular.
            """
            origen = self.bdi.get_belief("O")
            ox, oy = origen[0], origen[1]
            num_medicos = self.bdi.get_belief("X")
            desfase = self.bdi.get_belief("D")
            pos = []

            for i in range(num_medicos):
                radio = 10
                angle = desfase * (np.pi / 180) + i * (2 * np.pi / num_medicos)
                x, y = polar_to_cartesian(radio, angle)

                # Ajuste de la posición si no es transitable
                while not map.can_walk(ox + x, oy + y):
                    radio -= 1
                    x, y = polar_to_cartesian(radio, angle)
                
                pos.append((ox + x, oy + y))

            self.bdi.set_belief("posicionesM", pos)
            yield
        
        @actions.add(".calcularPosSoldados", 0)
        def _calcularPosSoldados(agent, term, intention):
            """
            Calcula las posiciones de los soldados alrededor de un origen en una formación circular.
            """
            origen = self.bdi.get_belief("O")
            ox, oy = origen[0], origen[1]
            num_soldados = self.bdi.get_belief("Y")
            desfase = self.bdi.get_belief("D")
            pos = []

            for i in range(num_soldados):
                radio = 25
                angle = desfase * (np.pi / 180) - i * (2 * np.pi / num_soldados)
                x, y = polar_to_cartesian(radio, angle)

                # Ajuste de la posición si no es transitable
                while not map.can_walk(ox + x, oy + y):
                    radio -= 1
                    x, y = polar_to_cartesian(radio, angle)
                
                pos.append((ox + x, oy + y))

            self.bdi.set_belief("posicionesS", pos)
            yield