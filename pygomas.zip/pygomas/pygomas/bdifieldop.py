import random

import numpy as np
from math import pi

from loguru import logger
from spade.behaviour import OneShotBehaviour

from .config import POWER_UNIT
from .ammopack import AmmoPack
from .bditroop import BDITroop, CLASS_FIELDOPS
from .ontology import AMMO_SERVICE

# Función para convertir coordenadas polares a cartesianas
def polar_to_cartesian(radius, angle):
    """
    Convierte coordenadas polares a cartesianas.

    Args:
        radius (float): El radio en coordenadas polares.
        angle (float): El ángulo en coordenadas polares.

    Returns:
        tuple: Coordenadas cartesianas (x, y).
    """
    x = radius * np.cos(angle)
    y = radius * np.sin(angle)
    return x, y

class BDIFieldOp(BDITroop):
    packs_delivered = 0
    ammo_pack_offset = 5

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.services.append(AMMO_SERVICE)
        self.eclass = CLASS_FIELDOPS

    def add_custom_actions(self, actions):
        super().add_custom_actions(actions)

        @actions.add(".reload", 0)
        def _cure(agent, term, intention):
            class CreateAmmoPackBehaviour(OneShotBehaviour):
                async def run(self):
                    await self.agent.create_ammo_pack()

            b = CreateAmmoPackBehaviour()
            self.add_behaviour(b)
            yield
            
        @actions.add(".calcularPosMedicos", 0)
        def _calcularPosMedicos(agent, term, intention):
            """
            Calcula las posiciones de los médicos alrededor de un origen en una formación circular.
            Si la creencia "O" no existe, se usa la posición actual del agente.
            """
            # Recupera o define el origen
            origen = self.bdi.get_belief("O")
            if origen is None:
                logger.warning("La creencia 'O' no está definida. Se usará la posición actual del agente.")
                origen = (self.movement.position.x, self.movement.position.z)
            ox, oy = origen[0], origen[1]

            # Recupera la cantidad de médicos; si no está definida, se asigna 1 por defecto
            num_medicos = self.bdi.get_belief("X")
            if num_medicos is None or num_medicos <= 0:
                logger.warning("La creencia 'X' no está definida o es inválida. Se asigna 1 como número de médicos.")
                num_medicos = 1

            # Recupera el desfase; si no existe, se asigna 0
            desfase = self.bdi.get_belief("D")
            if desfase is None:
                logger.warning("La creencia 'D' no está definida. Se asigna 0 para el desfase.")
                desfase = 0

            pos = []
            for i in range(num_medicos):
                radio = 10
                angle = desfase * (np.pi / 180) + i * (2 * np.pi / num_medicos)
                x, y = polar_to_cartesian(radio, angle)

                # Ajuste de la posición si no es transitable, con límite de intentos
                intentos = 0
                while not self.map.can_walk(ox + x, oy + y) and intentos < 10:
                    radio -= 1
                    if radio <= 0:
                        logger.warning(f"No se encontró posición transitable para el médico en el ángulo {angle:.2f}. Se usará el origen.")
                        x, y = 0, 0
                        break
                    x, y = polar_to_cartesian(radio, angle)
                    intentos += 1

                pos.append((ox + x, oy + y))

            self.bdi.set_belief("posicionesM", pos)
            yield


        @actions.add(".calcularPosSoldados", 0)
        def _calcularPosSoldados(agent, term, intention):
            """
            Calcula las posiciones de los soldados alrededor de un origen en una formación circular.
            Si la creencia "O" no existe, se usa la posición actual del agente.
            """
            # Recupera o define el origen
            origen = self.bdi.get_belief("O")
            if origen is None:
                logger.warning("La creencia 'O' no está definida. Se usará la posición actual del agente.")
                origen = (self.movement.position.x, self.movement.position.z)
            ox, oy = origen[0], origen[1]

            # Recupera la cantidad de soldados; si no está definida, se asigna 1 por defecto
            num_soldados = self.bdi.get_belief("Y")
            if num_soldados is None or num_soldados <= 0:
                logger.warning("La creencia 'Y' no está definida o es inválida. Se asigna 1 como número de soldados.")
                num_soldados = 1

            # Recupera el desfase; si no existe, se asigna 0
            desfase = self.bdi.get_belief("D")
            if desfase is None:
                logger.warning("La creencia 'D' no está definida. Se asigna 0 para el desfase.")
                desfase = 0

            pos = []
            for i in range(num_soldados):
                radio = 25
                angle = desfase * (np.pi / 180) - i * (2 * np.pi / num_soldados)
                x, y = polar_to_cartesian(radio, angle)

                # Ajuste si la posición no es transitable, con límite de intentos para evitar bucles infinitos
                intentos = 0
                while not self.map.can_walk(ox + x, oy + y) and intentos < 10:
                    radio -= 1
                    if radio <= 0:
                        logger.warning(f"No se encontró posición transitable para el soldado en el ángulo {angle:.2f}. Se usará el origen.")
                        x, y = 0, 0
                        break
                    x, y = polar_to_cartesian(radio, angle)
                    intentos += 1

                pos.append((ox + x, oy + y))

            self.bdi.set_belief("posicionesS", pos)
            yield



    def perform_ammo_action(self):
        # We can give ammo paks if we have power enough...
        if self.get_power() >= POWER_UNIT:
            self.use_power()
            return True
        return False

    async def create_ammo_pack(self):
        """
        Creates ammo packs if possible.

        This method allows to create ammo packs if there is enough power in the agent's power bar.

        :returns number of ammo packs created
        """

        logger.info("{} Creating ammo packs.".format(self.name))
        while self.perform_ammo_action():
            BDIFieldOp.packs_delivered += 1
            name = "ammopack_{}_{}@{}".format(
                self.jid.localpart, BDIFieldOp.packs_delivered, self.jid.domain
            )
            x = self.movement.position.x + random.random() * BDIFieldOp.ammo_pack_offset
            z = self.movement.position.z + random.random() * BDIFieldOp.ammo_pack_offset

            while not self.check_static_position(x, z):
                x = (
                    self.movement.position.x
                    + random.random() * BDIFieldOp.ammo_pack_offset
                )
                z = (
                    self.movement.position.z
                    + random.random() * BDIFieldOp.ammo_pack_offset
                )

            try:
                pack = AmmoPack(
                    name=name, passwd="secret", x=x, z=z, manager_jid=self.manager
                )
                await pack.start()
            except Exception as e:
                logger.warning(
                    "FieldOps {} could not create AmmoPack: {}".format(self.name, e)
                )

            logger.info("AmmoPack {} created.".format(name))