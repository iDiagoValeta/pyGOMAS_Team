import pygame
import time

pygame.init()

# Crear ventana
screen = pygame.display.set_mode((800, 600))

# Cargar imagen
try:
    img = pygame.image.load("assets/wall2.png")
    print("Imagen cargada correctamente:", img)
except pygame.error as e:
    print("Error al cargar la imagen:", e)

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    screen.fill((0, 0, 0))  # Fondo negro
    screen.blit(img, (100, 100))  # Dibuja la imagen
    pygame.draw.rect(screen, (255, 0, 0), (50, 50, 100, 100))  # Rectángulo rojo
    pygame.display.flip()  # Actualizar pantalla
    time.sleep(0.1)

pygame.quit()

