=====
Usage
=====

To use pygomas in a project::

    import pygomas
